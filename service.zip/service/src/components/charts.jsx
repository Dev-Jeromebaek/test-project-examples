import React, { Component } from "react";

class charts extends Component {
  render() {
    return <div>charts</div>;
  }
}

export default charts;
