import React, { Component } from 'react';

import { Container, Row, Col, Nav } from 'reactstrap';
import ApiMyUseFrame from '../components/api/ApiMyUseFrame';
// import ApiTotalFrame from '../components/api/ApiTotalFrame';
import createIcon from '../public/icons/create.svg';
import ApiDetailFrame from '../components/api/ApiDetailFrame';

class Api extends Component {
  apiId = 18;
  state = {
    ApiLists: [
      {
        apiId: 1,
        httpMethod: 'GET',
        apiName: '방문 이력',
        requestUrl: '/api/mock-api-1',
        isUsedApi: true,
      },
      {
        apiId: 2,
        httpMethod: 'POST',
        apiName: '판매 이력',
        requestUrl: '/api/mock-api-2',
        isUsedApi: true,
      },
      {
        apiId: 3,
        httpMethod: 'GET',
        apiName: '문의 이력',
        requestUrl: '/api/mock-api-3',
        isUsedApi: false,
      },
      {
        apiId: 4,
        httpMethod: 'GET',
        apiName: '방문 이력',
        requestUrl: '/api/mock-api-4',
        isUsedApi: true,
      },
      {
        apiId: 5,
        httpMethod: 'POST',
        apiName: '판매 이력',
        requestUrl: '/api/mock-api-5',
        isUsedApi: true,
      },
      {
        apiId: 6,
        httpMethod: 'GET',
        apiName: '문의 이력',
        requestUrl: '/api/mock-api-6',
        isUsedApi: false,
      },
      {
        apiId: 7,
        httpMethod: 'GET',
        apiName: '방문 이력',
        requestUrl: '/api/mock-api-7',
        isUsedApi: true,
      },
      {
        apiId: 9,
        httpMethod: 'POST',
        apiName: '판매 이력',
        requestUrl: '/api/mock-api-9',
        isUsedApi: true,
      },
      {
        apiId: 10,
        httpMethod: 'GET',
        apiName: '방문 이력',
        requestUrl: '/api/mock-api-10',
        isUsedApi: true,
      },
      {
        apiId: 11,
        httpMethod: 'POST',
        apiName: '판매 이력',
        requestUrl: '/api/mock-api-11',
        isUsedApi: true,
      },
      {
        apiId: 12,
        httpMethod: 'GET',
        apiName: '방문 이력',
        requestUrl: '/api/mock-api-12',
        isUsedApi: true,
      },
      {
        apiId: 13,
        httpMethod: 'POST',
        apiName: '판매 이력',
        requestUrl: '/api/mock-api-13',
        isUsedApi: true,
      },
      {
        apiId: 14,
        httpMethod: 'GET',
        apiName: '방문 이력',
        requestUrl: '/api/mock-api-14',
        isUsedApi: true,
      },
      {
        apiId: 15,
        httpMethod: 'POST',
        apiName: '판매 이력',
        requestUrl: '/api/mock-api-15',
        isUsedApi: true,
      },
      {
        apiId: 16,
        httpMethod: 'GET',
        apiName: '방문 이력',
        requestUrl: '/api/mock-api-16',
        isUsedApi: true,
      },
      {
        apiId: 17,
        httpMethod: 'POST',
        apiName: '판매 이력',
        requestUrl: '/api/mock-api-17',
        isUsedApi: true,
      },
    ],
  };

  handleModalOpen = () => {
    alert('Add Api Modal Open');
  };

  handleCreateApi = data => {
    console.log(data);
    const { ApiLists } = this.state;
    this.setState({
      ApiLists: ApiLists.concat(
        Object.assign({}, data, {
          apiId: this.apiId++,
        }),
      ),
    });
  };

  handleRemoveApi = id => {
    const { ApiLists } = this.state;

    this.setState({
      ApiLists: ApiLists.filter(apiOne => apiOne.apiId !== id),
    });
  };

  handleUpdateApi = (id, editData) => {
    const { ApiLists } = this.state;
    this.setState({
      ApiLists: ApiLists.map(apiOne => {
        if (apiOne.apiId === id) {
          return {
            id,
            ...editData,
          };
        }
        return apiOne;
      }),
    });
  };

  render() {
    const ContainerStyle = {
      width: '100vw',
      height: '83vh',
    };
    const overScroll = {
      overflowY: 'auto',
    };
    return (
      <Container style={ContainerStyle}>
        <Row className="h-100 w-100">
          <Col
            xs="12"
            sm="4"
            md="4"
            lg="3"
            className="border bg-secondary h-100 bg-light"
          >
            <div className="h-10 d-flex justify-content-center align-items-center border-bottom">
              현재 사용중 API
            </div>
            <div className="h-80 pt-3 pb-3" style={overScroll}>
              <ApiMyUseFrame
                apiList={this.state.ApiLists}
                onRemove={this.handleRemoveApi}
              />
            </div>
            <div className="h-10 d-flex justify-content-center align-items-center border-top">
              <img
                src={createIcon}
                wdith="40"
                height="40"
                alt=".."
                className="shadow rounded-circle cursor-pointer"
                onClick={this.handleModalOpen}
                // onCreate={this.handleCreateApi}
              />
            </div>
          </Col>
          <Col xs="12" sm="8" md="8" lg="9" style={overScroll}>
            <ApiDetailFrame
              apiList={this.state.ApiLists}
              onUpdate={this.handleUpdateApi}
              onRemove={this.handleRemoveApi}
            />
          </Col>
        </Row>
      </Container>
    );
  }
}

export default Api;
