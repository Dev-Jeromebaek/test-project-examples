import React, { Component } from 'react';
import { NavLink as RouteLink } from 'react-router-dom';

class ApiMyUseList extends Component {
  state = {
    path: '/api/' + this.props.info.id,
  };

  render() {
    const { info } = this.props;
    return (
      <RouteLink to={this.state.path} className="nav-link btn btn-outline-tmon">
        <img
          src="http://img1.tmon.kr/static/common/gnb_slim_logo.png"
          alt="티몬로고"
          wdith="20"
          height="20"
        />
        &nbsp; {info.name}
      </RouteLink>
    );
  }
}

export default ApiMyUseList;
