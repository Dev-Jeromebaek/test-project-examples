import React, { Component } from 'react';

import { Route, Switch } from 'react-router-dom';

import ApiDetailInfo from './ApiDetailInfo';
import ApiTotalFrame from './ApiTotalFrame';

class ApiDetailFrame extends Component {
  static defaultProps = {
    apiList: [],
  };

  render() {
    const { apiList, onUpdate, onRemove } = this.props;
    if (!apiList) return null;
    console.log('rendering list');
    console.log(apiList);
    return (
      <Switch>
        <Route exact path="/api" component={ApiTotalFrame} apiList={apiList} />
        <Route path="/api/:id" component={ApiDetailInfo} apiList={apiList} />
      </Switch>
    );
  }
}

export default ApiDetailFrame;
