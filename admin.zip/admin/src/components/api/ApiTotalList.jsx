import React, { Component } from 'react';
import {
  UncontrolledCollapse,
  Button,
  CardBody,
  Card,
  Badge,
  Row,
  Col,
} from 'reactstrap';

export default class ApiTotalList extends Component {
  state = {
    api: this.props.api,
    toggelr: 'toggler' + this.props.api.apiId,
    matchToggler: '#toggler' + this.props.api.apiId,
  };
  render() {
    return (
      <div className="mb-3">
        <Button
          // color="danger"
          id={this.state.toggelr}
          className="mb-1 w-100 text-left container shadow btn-light"
        >
          <Row className="m-0">
            <Col xs="1" sm="1" md="1" lg="1">
              {this.state.api.isUsedApi ? 'Use ' : 'Not '}
            </Col>
            <Col>
              {this.state.api.httpMethod === 'GET' ? (
                <Badge color="primary" pill xs="12" sm="4" md="4" lg="3">
                  {this.state.api.httpMethod}
                </Badge>
              ) : (
                <Badge color="success" pill>
                  {this.state.api.httpMethod}
                </Badge>
              )}
            </Col>
            <Col xs="9" sm="9" md="9" lg="9">
              {this.state.api.requestUrl}
            </Col>
          </Row>
        </Button>

        <UncontrolledCollapse
          toggler={this.state.matchToggler}
          className="shadow"
        >
          <Card>
            <CardBody>{this.state.api.apiName}</CardBody>
          </Card>
        </UncontrolledCollapse>
      </div>
    );
  }
}
