import React, { Component } from 'react';
import ApiTotalList from './ApiTotalList';

class ApiTotalFrame extends Component {
  render() {
    console.log(this.props.apiList);
    return <div>{this.props.apiList}</div>;
  }
}

export default ApiTotalFrame;
