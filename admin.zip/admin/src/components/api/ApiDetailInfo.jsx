import React, { Component } from 'react';

class ApiDetailInfo extends Component {
  // constructor(props) {
  //   super(props);
  //   // console.log(this.props.match.params.id);
  //   // console.log(this.props);
  // }
  render() {
    return <div>id : {this.props.match.params.id}</div>;
  }
}

export default ApiDetailInfo;
