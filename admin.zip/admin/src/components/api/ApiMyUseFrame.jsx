import React, { Component, Fragment } from 'react';

import ApiMyUseList from './ApiMyUseList';

class ApiMyUseFrame extends Component {
  id = 9;
  state = {
    info: [
      {
        id: '0',
        name: '배송딜별 api',
      },
      {
        id: '1',
        name: '반품딜별 api',
      },
      {
        id: '2',
        name: '티켓딜별 api',
      },
      {
        id: '3',
        name: '시간대별 api',
      },
      {
        id: '4',
        name: '사용자별 api',
      },
      {
        id: '5',
        name: '사용자별 api',
      },
      {
        id: '6',
        name: '사용자별 api',
      },
      {
        id: '7',
        name: '사용자별 api',
      },
      {
        id: '8',
        name: '사용자별 api',
      },
    ],
  };

  handleCreateMyApi = data => {
    this.setState({
      info: this.info.concat(
        Object.assign({}, data, {
          id: this.id++,
        }),
      ),
    });
  };

  handleRemoveMyApi = id => {
    const { info } = this.state;
    this.setState({
      info: info.filter(newInfo => newInfo.id !== id),
    });
  };

  render() {
    const list = this.state.info.map(info => (
      <ApiMyUseList
        key={info.id}
        info={info}
        onCreate={this.handleCreateMyApi}
        onRemove={this.handleRemoveMyApi}
      />
    ));
    return <Fragment>{list}</Fragment>;
  }
}

export default ApiMyUseFrame;
