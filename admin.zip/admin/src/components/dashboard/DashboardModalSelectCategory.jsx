import React from 'react';

export default class DashboardModalSelectCategory extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return <div />;
  }
}
